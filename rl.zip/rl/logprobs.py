from __future__ import annotations

import torch
import torch.nn.functional as F


def gather_response_logprobs(model, input_ids: torch.Tensor, attention_mask: torch.Tensor, response_mask: torch.Tensor) -> torch.Tensor:
    """Return per-token logprobs aligned to input_ids positions.

    For a causal LM, logits at position j-1 predict token input_ids[j]. This
    function therefore gathers logprobs from logits[:, :-1] against
    input_ids[:, 1:], then pads a zero column at j=0. The returned tensor has
    shape [B, T], where logprobs[b, j] is the logprob of input_ids[b, j].

    Position j=0 has no preceding logits and must be excluded by response_mask.
    The effective mask is response_mask & attention_mask, so prompt tokens and
    pad tokens do not contribute to GRPO loss even though their logprobs are
    present in the returned aligned tensor.
    """
    if input_ids.shape != attention_mask.shape or input_ids.shape != response_mask.shape:
        raise ValueError(
            "input_ids, attention_mask, and response_mask must have the same shape; "
            f"got {tuple(input_ids.shape)}, {tuple(attention_mask.shape)}, {tuple(response_mask.shape)}"
        )
    outputs = model(input_ids=input_ids, attention_mask=attention_mask, use_cache=False)
    logits = outputs.logits
    if logits.shape[:2] != input_ids.shape:
        raise ValueError(f"logits shape {tuple(logits.shape)} is incompatible with input_ids {tuple(input_ids.shape)}")

    shifted_logits = logits[:, :-1, :].to(torch.float32)
    shifted_labels = input_ids[:, 1:]
    shifted_logprobs = F.log_softmax(shifted_logits, dim=-1)
    gathered = shifted_logprobs.gather(dim=-1, index=shifted_labels.unsqueeze(-1)).squeeze(-1)
    zero_first = gathered.new_zeros((gathered.shape[0], 1))
    aligned = torch.cat([zero_first, gathered], dim=1).to(dtype=logits.dtype)

    effective_mask = (response_mask.to(dtype=torch.bool) & attention_mask.to(dtype=torch.bool)).to(dtype=aligned.dtype)
    j0 = torch.zeros((effective_mask.shape[0], 1), dtype=effective_mask.dtype, device=effective_mask.device)
    effective_mask = torch.cat([j0, effective_mask[:, 1:]], dim=1)
    return aligned * effective_mask
